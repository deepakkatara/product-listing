export const ROUTES = {
  HOME: "/",
  DETAILS: "/details",
} as const;
