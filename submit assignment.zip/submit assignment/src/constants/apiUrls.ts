export const baseURL: string = "https://pokeapi.co/api/v2";
export const LIMIT: number = 12;
export const SEARCH_SLICED: number = 30;
